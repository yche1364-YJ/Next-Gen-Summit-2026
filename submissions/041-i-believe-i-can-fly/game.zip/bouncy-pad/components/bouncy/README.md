# Bouncy Component

Makes the player bounce when they land on something — or, rotated, bounce off a wall. There are two ways to use it:

| | Bouncy Pad | Bouncy component |
|---|---|---|
| File | `bouncy_pad.tscn` | `bouncy.tscn` |
| What it is | A ready-made trampoline you drag into a level | Attach it to **any object** to make that object bouncy |
| Good for | Beginners | Anyone who wants platforms, enemies, rocks… to bounce |

**Already in the game:** the main level (`main.tscn`) has a trampoline (`BouncyPad`) and a bouncy platform (`Platforms/BouncyPlatform`). Click them in the Scene dock to change their settings, then press **F5**.

---

## Option 1: Place a trampoline

1. Open a level (for example `main.tscn`) and switch to the **2D** view at the top.
2. In the **FileSystem** dock (bottom left), find `components/bouncy/bouncy_pad.tscn` and **drag it into the level**.
3. The trampoline's origin is at the **bottom-centre** of the picture, so place it on the ground.
4. Adjust the settings in the **Inspector** on the right, then press F5 to play.

## Option 2: Make any object bouncy

1. In the **Scene** dock (top left), **right-click** the object you want to make bouncy (for example a Platform) → **Instantiate Child Scene**, and choose `components/bouncy/bouncy.tscn`.
2. Move the new Bouncy node to the object's **top surface** (the pink box should stick out slightly above the surface).
3. In the Inspector, set **Zone Width** so the pink box is as wide as the object (a Platform is 128 px per tile).
4. Adjust the settings and press F5 to play.

## Bouncy walls and slopes

Rotate a trampoline (or any object with Bouncy) and it launches the player **out of its face**, in whatever direction it points:

1. Select the trampoline and, in the Inspector, open **Transform** → set **Rotation** to **-90** (wall that pushes left) or **90** (wall that pushes right). A value like 45 makes a slope.
2. Place it so its pink face points where the player comes from.
3. Use **Launch Angle** to tilt the direction further, for example so a wall pushes the player out *and* up.

In the editor, a **yellow arrow** shows exactly where the player will be launched. It's only visible in the editor, not in the game.

---

## Settings you can change

| Setting | What it does | Default |
|---|---|---|
| **Bounce Height** | How hard the player is launched. Lying flat with Launch Angle 0, it's exactly how high they go, in pixels (a normal jump is about 395) | 600 |
| **Launch Angle** | Tilts the launch direction, in degrees. 0 = straight out of the bouncy face; positive tilts clockwise, negative counterclockwise. Watch the yellow arrow | 0 |
| **Zone Width** (Bouncy component) | How wide the pink bounce zone is, in pixels | 128 |
| **Hold Jump Boost** | Extra height (%) if the player holds the jump key while landing | 30% |
| **Squash Effect** | Squash-and-stretch effect when bounced on | On |
| **Bounce Sound** | Sound played when bounced on (the pad uses "boing" by default) | — |
| **Texture** (Bouncy Pad only) | The trampoline's picture | Pink trampoline |

> Try this: set Bounce Height to 395 and the bounce will be exactly as high as a normal jump. Then lower the Gravity on GameLogic and bounce again — the height stays the same, but you float in the air for longer!

## Use your own picture

1. Prepare a PNG (about 128 pixels wide, with a transparent background works best).
2. **Drag** the PNG into the **FileSystem** dock (bottom left) — `components/bouncy/` is a good place for it.
3. Select the trampoline in your level, then **drag** the PNG from the FileSystem dock onto the **Texture** field in the Inspector.
4. The collision area resizes to fit the picture automatically — nothing else to change.

To go back to the original picture: right-click the Texture field → **Clear**.

---

## How does it work? (for the curious)

`bouncy.gd` is an **Area2D** (a detection zone). When a player enters the zone while moving towards its face, it sets the player's speed to point out of the face:

```gdscript
var speed := sqrt(2.0 * gravity * height)
character.velocity = launch_direction() * speed
```

This is the physics formula **v = √(2gh)**: the starting speed you need to reach a height of h. That's why you only have to enter a *height* — the script works out the speed from the current gravity. The direction comes from the object's rotation plus **Launch Angle**.

When the push is sideways, the player can't steer left/right for 0.4 seconds, so the push actually carries them away (otherwise the Player script would brake almost instantly).
